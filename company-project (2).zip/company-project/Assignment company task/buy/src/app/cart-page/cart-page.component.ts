import { Component, OnInit } from '@angular/core';
import * as angular from "@angular/core";
import { Router } from '@angular/router';
@Component({
  selector: 'app-cart-page',
  templateUrl: './cart-page.component.html',
  styleUrls: ['./cart-page.component.css']
})
export class CartPageComponent implements OnInit {
  addNumber: number = 1;
  add: number;
  adddisabled: boolean;
  subsdisabled: boolean;
  price: string;

  // subs: number;
  availableSchoos = [{ name: 'Puma', id: 1, imageSrc: 'assets/soepics/soe1.jpeg', price: 299, add: 1, total: 299 },
  { name: 'Addidas', id: 2, imageSrc: 'assets/soepics/soe1.jpeg', price: 499, add: 1, total: 499 },
  { name: 'Rebook', id: 3, imageSrc: 'assets/soepics/soe1.jpeg', price: 399, add: 1, total: 399 }];
  getdata: any = [];
  totalAmount: any;


  constructor(private router: Router) { }

  ngOnInit() {
    this.getproduct()
  }

  getproduct() {
    var getid = []
    getid = JSON.parse(localStorage.getItem('cart'))
    this.getdata = this.availableSchoos.filter(ele => getid.includes(ele.id))
    this.totalAmount = this.getdata.reduce(function (acc, value) {
      return acc + value.total;
    }, 0);
  }


  increment(id, ind) {
    
    this.getdata.map(ele => {
      if (ele.id == id) {

        if (ele.add >= 10) {
          this.adddisabled = true;
        } else {
          ele.add = ele.add + 1;
          ele.total = (ele.add * ele.price);
        }
      }
      this.totalAmount = ele
    })

    this.totalAmount = this.getdata.reduce(function (acc, value) {
      return acc + value.total;
    }, 0);



  }
  decrement(id) {
    this.getdata.map(ele => {
      if (ele.id == id) {
        if (ele.add <= 1) {
          this.subsdisabled = true;
        } else {
          ele.add = ele.add - 1;
          ele.total = (ele.add * ele.price);
        }
      }

    })
    this.totalAmount = this.getdata.reduce(function (acc, value) {
      return acc + value.total;
    }, 0);

    localStorage.setItem
    // console.log('==>', this.totalAmount)

  }
  buyItems() {
    localStorage.removeItem('cart')
    alert("Your item is ready. It will reach at your destination tommorrow!! Thankyou");
    this.router.navigate(['/product-page']);
  }

  delete(id) {
    var getid = []
    getid = JSON.parse(localStorage.getItem('cart'))
    console.log('get', id)

    var ind = getid.findIndex(ele => ele == id)
    if (ind != -1) {
      getid.splice(ind, 1)
      localStorage.setItem('cart', JSON.stringify(getid))
      alert("Your item is  remove sucessfully");
      this.getproduct()

    }
  }




}
