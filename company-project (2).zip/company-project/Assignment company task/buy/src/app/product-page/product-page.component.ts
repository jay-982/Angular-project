import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-product-page',
  templateUrl: './product-page.component.html',
  styleUrls: ['./product-page.component.css']
})
export class ProductPageComponent implements OnInit {
  constructor( private router:Router) { }


  availableShoes = [{ name: 'Puma', id: 1, imageSrc: 'assets/soepics/soe1.jpeg',price: 299 },
   { name: 'Addidas', id: 2, imageSrc: 'assets/imagess copy.jpeg',price: 499 },
  { name: 'Reebok', id: 3, imageSrc: 'assets/download (1).jpeg' ,price: 399 }];

  shoes = [
    { id: 1, viewValue: 'Addidas' },
    { id: 2, viewValue: 'Puma' },
    { id: 3, viewValue: 'Reebok' }
   
  ];
  data:any=[]
  ngOnInit() {

  }

  addCart(id){
    this.data=[]
     var getid=[]
     var ind= -1
     getid = JSON.parse(localStorage.getItem('cart'))
     console.log('get',getid)
     if(getid != null){
      ind = getid.findIndex(ele=>ele==id)
      this.data =getid
     }
     
     
     if(ind== -1){
      this.data.push(id)
      localStorage.setItem('cart',JSON.stringify(this.data))
     alert("You product is added to the cart!");
     }
     else{
      alert("You product is already added to the cart!");
     }
    
  }

  gotoCart(){
    this.router.navigate(['/cart-page']);
  }
 

}
